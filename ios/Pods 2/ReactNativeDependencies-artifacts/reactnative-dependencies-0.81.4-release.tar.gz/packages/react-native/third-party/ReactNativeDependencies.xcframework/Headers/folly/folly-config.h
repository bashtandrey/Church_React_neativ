#pragma once

#define FOLLY_MOBILE 1
#define FOLLY_HAVE_PTHREAD 1
#define FOLLY_USE_LIBCPP 1
#define FOLLY_CFG_NO_COROUTINES 1
#define FOLLY_HAVE_CLOCK_GETTIME 1 

#pragma clang diagnostic ignored "-Wcomma"
